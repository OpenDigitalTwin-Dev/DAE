var class_qwt_spline_local =
[
    [ "Type", "class_qwt_spline_local.html#a1b65106f91b7cdbc7a389f3389041407", [
      [ "Cardinal", "class_qwt_spline_local.html#a1b65106f91b7cdbc7a389f3389041407ad691c00c49d088f841cb3068ba960b41", null ],
      [ "ParabolicBlending", "class_qwt_spline_local.html#a1b65106f91b7cdbc7a389f3389041407ad4323015af5b06447bd4a6ac84c60f3c", null ],
      [ "Akima", "class_qwt_spline_local.html#a1b65106f91b7cdbc7a389f3389041407a119134ba7624f50c37a57cdd7a862dc2", null ],
      [ "PChip", "class_qwt_spline_local.html#a1b65106f91b7cdbc7a389f3389041407acf64689481d8f90d5cbc2fa4e7a08958", null ]
    ] ],
    [ "QwtSplineLocal", "class_qwt_spline_local.html#abd008f03f1c466d2f8c9358ad3772874", null ],
    [ "~QwtSplineLocal", "class_qwt_spline_local.html#a40032cd1cab6e9ec600bbbd7849988a3", null ],
    [ "bezierControlLines", "class_qwt_spline_local.html#af41043d3b8c664c99f3c38a9f6e8c141", null ],
    [ "locality", "class_qwt_spline_local.html#a76371196a0f089b7aaebafb691bbd7ce", null ],
    [ "painterPath", "class_qwt_spline_local.html#aaf946d9c3fce948f4cab2d950b13c16a", null ],
    [ "polynomials", "class_qwt_spline_local.html#afcf07ad4628e9b5cab639e3c7a0e64e7", null ],
    [ "slopes", "class_qwt_spline_local.html#af86995e3805a71c68a623145044d36c2", null ],
    [ "type", "class_qwt_spline_local.html#a5cb4f022abee9d29f6f7ef6b670df776", null ]
];