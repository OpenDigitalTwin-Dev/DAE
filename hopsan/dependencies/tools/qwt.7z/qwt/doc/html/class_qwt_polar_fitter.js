var class_qwt_polar_fitter =
[
    [ "QwtPolarFitter", "class_qwt_polar_fitter.html#a88d0ab40691bab03bd52399bce35f46b", null ],
    [ "~QwtPolarFitter", "class_qwt_polar_fitter.html#af44b4b5f62393add4ea35b11b6723c12", null ],
    [ "fitCurve", "class_qwt_polar_fitter.html#a99fda3a39854c5d9f2f77b66a05ef295", null ],
    [ "fitCurvePath", "class_qwt_polar_fitter.html#a851d043e4787663297a489593d33841f", null ],
    [ "setStepCount", "class_qwt_polar_fitter.html#a3250f0d3fe6e7a658ce46920fe7efcab", null ],
    [ "stepCount", "class_qwt_polar_fitter.html#a181f2ad00cb7e8e23ff91e78cedc4ea0", null ]
];