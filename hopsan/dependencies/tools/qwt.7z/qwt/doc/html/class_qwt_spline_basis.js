var class_qwt_spline_basis =
[
    [ "QwtSplineBasis", "class_qwt_spline_basis.html#a84187686884d133830ea4c94fd57ff17", null ],
    [ "~QwtSplineBasis", "class_qwt_spline_basis.html#a623c89b2080e099bac2c39c0418bfa84", null ],
    [ "locality", "class_qwt_spline_basis.html#a1eeb7e3edab36759d523613bb80c69db", null ],
    [ "painterPath", "class_qwt_spline_basis.html#af6be32c8dbfb01f1110504d949088b3b", null ]
];