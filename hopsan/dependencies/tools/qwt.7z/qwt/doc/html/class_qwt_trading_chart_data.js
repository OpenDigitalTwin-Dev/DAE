var class_qwt_trading_chart_data =
[
    [ "QwtTradingChartData", "class_qwt_trading_chart_data.html#abfe5df45f8a6313b68e93715c7bbfb7b", null ],
    [ "boundingRect", "class_qwt_trading_chart_data.html#ae9b4d57fd16690363ee831f37fcd4786", null ]
];