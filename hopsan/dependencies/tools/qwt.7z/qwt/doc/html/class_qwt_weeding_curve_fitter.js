var class_qwt_weeding_curve_fitter =
[
    [ "QwtWeedingCurveFitter", "class_qwt_weeding_curve_fitter.html#a7deb4d070a329cbdee454023194898a7", null ],
    [ "~QwtWeedingCurveFitter", "class_qwt_weeding_curve_fitter.html#abbd30a948fc6974f881678f80a29768c", null ],
    [ "chunkSize", "class_qwt_weeding_curve_fitter.html#adfffe6d108f7170bafe5cc81379eaef7", null ],
    [ "fitCurve", "class_qwt_weeding_curve_fitter.html#a374b476ce3ea491760ff7d0ccda0fedf", null ],
    [ "fitCurvePath", "class_qwt_weeding_curve_fitter.html#ad5c04dcd161b8e238c53a753716eff5c", null ],
    [ "setChunkSize", "class_qwt_weeding_curve_fitter.html#a9f17a819447cba0e733bd71d90ee2766", null ],
    [ "setTolerance", "class_qwt_weeding_curve_fitter.html#a62c303f6826fef2be7b7bbe82f530680", null ],
    [ "simplify", "class_qwt_weeding_curve_fitter.html#a6cc9c1ec020967b6f56c8d0e2ad374b4", null ],
    [ "tolerance", "class_qwt_weeding_curve_fitter.html#a484813f52d921cc5dc57bb6dcf82668d", null ]
];