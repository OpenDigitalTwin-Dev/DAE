var class_qwt_linear_color_map =
[
    [ "Mode", "class_qwt_linear_color_map.html#ac8c5f1991f533b1d25a9a0a0874b7d54", [
      [ "FixedColors", "class_qwt_linear_color_map.html#ac8c5f1991f533b1d25a9a0a0874b7d54a564b5243ab2c5e4c972a6b645234c651", null ],
      [ "ScaledColors", "class_qwt_linear_color_map.html#ac8c5f1991f533b1d25a9a0a0874b7d54a01770189cb40240f2fe7fe2e6c1523f1", null ]
    ] ],
    [ "QwtLinearColorMap", "class_qwt_linear_color_map.html#a0ef6a29bb027017aad89a4c4a4b07019", null ],
    [ "QwtLinearColorMap", "class_qwt_linear_color_map.html#ae591cf441db15a021c25d0b58bfa7a5e", null ],
    [ "~QwtLinearColorMap", "class_qwt_linear_color_map.html#a82caa759e44d439aa9866bd03e2e3696", null ],
    [ "addColorStop", "class_qwt_linear_color_map.html#aa7162a034e882e752c15051439bb2c99", null ],
    [ "color1", "class_qwt_linear_color_map.html#afc26d903d0bc7a9ff3059eab9bc41c50", null ],
    [ "color2", "class_qwt_linear_color_map.html#aedf72ce7e3d0059b5a8e6b197a67f796", null ],
    [ "colorIndex", "class_qwt_linear_color_map.html#a29d5c17eaf6b061c679cfb472eb8f91b", null ],
    [ "colorStops", "class_qwt_linear_color_map.html#a25ab45fbb2e2f86c7e8de92477ec43f7", null ],
    [ "mode", "class_qwt_linear_color_map.html#a0f1252586f1a4eac8241b89f0764abba", null ],
    [ "rgb", "class_qwt_linear_color_map.html#abc40b8e76b9efb89608a0e35d2bed688", null ],
    [ "setColorInterval", "class_qwt_linear_color_map.html#abfae35c30755c0bbd1447342055e9a13", null ],
    [ "setMode", "class_qwt_linear_color_map.html#afca7397fb6d07d05bab83e83e274a9c2", null ]
];